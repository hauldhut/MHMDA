import os
import pandas as pd
import numpy as np

dataset = "miR2Disease"
# Create output directory
output_dir = f"./data/{dataset}"
os.makedirs(output_dir, exist_ok=True)

# Read input files
disease_sim = pd.read_csv("../../Data/DiseaseSimNet_OMIM.txt", sep="\t", header=None, names=["disease1", "weight", "disease2"])
mirna_sim = pd.read_csv("../../Data/HomomiRNAIntegrated.txt", sep="\t", header=None, names=["mirna1", "weight", "mirna2"])
bipartite = pd.read_csv(f"../../Data/Phenotype2miRNAs_{dataset}.txt_BinaryInteraction.csv", sep=",")

# Get common miRNAs and diseases
common_mirnas = sorted(set(mirna_sim["mirna1"]).union(mirna_sim["mirna2"]) & set(bipartite["miRNA"]))
common_diseases = sorted(set(disease_sim["disease1"]).union(disease_sim["disease2"]) & set(bipartite["disease"]))

# Create miRNA index file
mirna_index = pd.DataFrame({
    "index": range(1, len(common_mirnas) + 1),
    "miRNA": common_mirnas
})
mirna_index.to_csv(os.path.join(output_dir, "miRNA number.txt"), sep="\t", index=False, header=False)

# Create disease index file
disease_index = pd.DataFrame({
    "index": range(1, len(common_diseases) + 1),
    "disease": common_diseases
})
disease_index.to_csv(os.path.join(output_dir, "disease number.txt"), sep="\t", index=False, header=False)

# Create known disease-miRNA associations with indices
mirna_to_index = dict(zip(mirna_index["miRNA"], mirna_index["index"]))
disease_to_index = dict(zip(disease_index["disease"], disease_index["index"]))
associations = bipartite[bipartite["miRNA"].isin(common_mirnas) & bipartite["disease"].isin(common_diseases)].copy()
associations["mirna_index"] = associations["miRNA"].map(mirna_to_index)
associations["disease_index"] = associations["disease"].map(disease_to_index)
associations[["mirna_index", "disease_index"]].to_csv(
    os.path.join(output_dir, "known disease-miRNA association number.txt"), sep="\t", index=False, header=False
)

# Create disease similarity matrix
disease_matrix = np.zeros((len(common_diseases), len(common_diseases)))
disease_index_dict = dict(zip(common_diseases, range(len(common_diseases))))
for _, row in disease_sim.iterrows():
    if row["disease1"] in common_diseases and row["disease2"] in common_diseases:
        i = disease_index_dict[row["disease1"]]
        j = disease_index_dict[row["disease2"]]
        disease_matrix[i, j] = row["weight"]
        disease_matrix[j, i] = row["weight"]
np.fill_diagonal(disease_matrix, 1)
np.savetxt(os.path.join(output_dir, "disease semantic similarity matrix 1.txt"), disease_matrix, delimiter="\t", fmt="%.6f")

# Create binary disease similarity matrix
binary_disease_matrix = (disease_matrix > 0).astype(int)
np.fill_diagonal(binary_disease_matrix, 1)
np.savetxt(os.path.join(output_dir, "disease semantic similarity weight matrix.txt"), binary_disease_matrix, delimiter="\t", fmt="%d")

# Create miRNA similarity matrix
mirna_matrix = np.zeros((len(common_mirnas), len(common_mirnas)))
mirna_index_dict = dict(zip(common_mirnas, range(len(common_mirnas))))
for _, row in mirna_sim.iterrows():
    if row["mirna1"] in common_mirnas and row["mirna2"] in common_mirnas:
        i = mirna_index_dict[row["mirna1"]]
        j = mirna_index_dict[row["mirna2"]]
        mirna_matrix[i, j] = row["weight"]
        mirna_matrix[j, i] = row["weight"]
np.fill_diagonal(mirna_matrix, 1)
np.savetxt(os.path.join(output_dir, "miRNA functional similarity weight matrix.txt"), mirna_matrix, delimiter="\t", fmt="%.6f")

# Create binary miRNA similarity matrix
binary_mirna_matrix = (mirna_matrix > 0).astype(int)
np.fill_diagonal(binary_mirna_matrix, 1)
np.savetxt(os.path.join(output_dir, "miRNA functional similarity matrix.txt"), binary_mirna_matrix, delimiter="\t", fmt="%d")